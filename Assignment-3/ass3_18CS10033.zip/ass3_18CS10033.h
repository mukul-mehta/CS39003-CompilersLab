#ifndef _HEADER_H
    #define _HEADER_H 

    #define KEYWORD         10
    #define IDENTIFIER      20
    #define CONSTANT        30
    #define STRING_LITERAL  40
    #define PUNCTUATOR      50

#endif
