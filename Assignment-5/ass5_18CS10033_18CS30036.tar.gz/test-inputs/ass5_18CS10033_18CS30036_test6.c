#include <stdio.h>

int count_retired(int age[], int limit, int num);

int main()
{
  int age[5];

  age[0] = 10;
  age[1] = 15;
  age[2] = 45;
  age[3] = 100;
  age[4] = 120;

  int tempCount = count_retired(age, 50, 5);

  printf("The number of retired people is %d", tempCount);
  return 0;
}

int count_retired(int age[], int limit, int num)
{
  int tempCount = 0;
  for (int i = 0; i < num; ++i)
    if (age[i] > limit)
      tempCount++;
  return tempCount;
}