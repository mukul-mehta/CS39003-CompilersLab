int Minimum(int a, int b)
{
  return (a < b) ? a : b;
}

int BreadthFirstSearch(int V, int residual_graph[V][V], int s, int t, int ancestor[])
{
  int i, max_residue[V], visited[V], queue[10000], front, rear;

  for (i = 0; i < V; i++)
  {
    max_residue[i] = 10000;
    visited[i] = 0;
  }

  queue[0] = s - 1, front = 0, rear = 0;
  visited[s - 1] = 1;
  ancestor[s - 1] = -1;

  while (front <= rear)
  {
    int u = queue[front++];

    if (u == t - 1)
      return 1;

    for (int v = 0; v < V; v++)
    {
      if (visited[v] == 0 && residual_graph[u][v] > 0)
      {
        queue[++rear] = v;
        max_residue[v] = Minimum(max_residue[u], residual_graph[u][v]);
        ancestor[v] = u;
        visited[v] = 1;
      }
      else if (visited[v] == 1 && residual_graph[u][v] > 0)
      {
        int temp = Minimum(max_residue[u], residual_graph[u][v]);
        if (temp > max_residue[v])
        {
          max_residue[v] = temp;
          ancestor[v] = u;
        }
      }
    }
  }
  return (visited[t - 1] == 1);
}

int main()
{
  return 1;
}