void switcher(int *x, int *y)
{
  int t;
  t = *x;
  *x = *y;
  *y = t;
}

void main()
{
  int i, a[10], v = 5;
  double moby = 98598.084830;
  char *g;
  g = (void *)0;

  for (i = 1; i < a[10]; i++)
    switcher(&i, &v);
  do
    i = i - 1;
  while (a[i] < v);
  i = 2;
  if (i && v)
    i = 1;
  while (v > a[i])
    i--;

  return;
}